package com.mywork.learningMaven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/* copy from Selenium helper
 * 
 */
import java.util.List;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions; 



/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );

/*        
        System.setProperty("webdriver.gecko.driver", ".\\webdrivers\\geckodriver.exe");
        WebDriver driver = new FirefoxDriver();      
       
        SeleniumHelper.GetInstance().GetDriver(WebDriverType.CHROME);
*/

//new        private static final Logger log ;
//new        private String myurl = "http://automationpractice.com/index.php";
        
  
/*    	System.setProperty("webdriver.chrome.driver", "\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe");
*/

    	    	 
    	 
    	  System.setProperty("webdriver.chrome.driver", "\\Selenium\\chromedriver_win32\\chromedriver.exe");
    	  WebDriver driver = new ChromeDriver();
// new    	  log.info("Generating ChromeDriver...");
/*
    	  return driver;
*/
  
    	
    	
/*    	
 * private final String pathToChromeDriver = "./webdrivers/chromedriver.exe";
*/
    	
// new    	private final String pathToChromeDriver = ".\\\\Selenium\\\\chromedriver_win32\\\\chromedriver.exe";
/*
    	public WebDriver GetDriver()
    	 {
    	 if (driver == null)
    	 {
    	 System.setProperty("webdriver.chrome.driver", pathToChromeDriver);
    	 driver = new ChromeDriver();
    	 log.info("Generating ChromeDriver...");
    	 }
    	 return driver;
    	 }
*/
    	/*
    	public void CloseDriver()
    	 {
    		 if (driver != null)
    		 {
    		 log.info("Closing Chrome Driver");
    		 driver.quit();
    		 }
    	 }
*/
        
        
    }
    
}
