package pageobjects;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject
{
private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
private static MyStoreShoppingCartPage m_instance;

//In Stock 
//@FindBy(xpath = //*[@id="product_5_19_0_184155"]/td[3]/span)
@FindBy(xpath = "//*[@id=\"cart_summary\"]/tbody/tr[1]/td[3]")
WebElement stockAvail;

// //*[@id="center_column"]/p[2]/a[1]
//@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
//*[@id="center_column"]/p[2]/a[1]/span/i
//@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")
//*[@id="center_column"]/p[2]/a[1]/span/text()
//@FindBy(xpath = "//a[@class='button btn btn-default standard-checkout button-medium']")
//@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]/span/text()")

@FindBy(xpath = "//a[@title='Proceed to checkout' and @class='button btn btn-default standard-checkout button-medium']")
WebElement proceedToCheckoutButton;

//*[@id="center_column"]/form/p/button/span
@FindBy(xpath = "//*[@id=\"center_column\"]/form/p/button/span")
WebElement proceedToCheckButton;

@FindBy(xpath = "//button[@type='submit' and @name='processAddress']")
WebElement checkOutButton;

@FindBy(xpath = "//input[@id='cgv']")
WebElement checkBox;

@FindBy(xpath = "//button[@type='submit' and @name='processCarrier']")
WebElement shippingCheckoutbutton;

@FindBy(xpath = "//a[@title='Pay by check.']")
WebElement payByCheckoption;

//@FindBy(xpath = "//*[@id=\"center_column\"]/form/div/h3")
@FindBy(xpath = "//h3[@class='page-subheading']")
WebElement odrSummaryheader;

@FindBy(xpath = "//button[@type='submit' and @class='button btn btn-default button-medium']")
WebElement conirmOdrbutton;

/*
@FindBy(xpath = "//*[@id=\"center_column\"]/p[1]/text()")
WebElement confirmationMessage;
*/


private MyStoreShoppingCartPage(WebDriver _driver)
{
	m_pageTitle = "My account - My Store";
	PageFactory.initElements(_driver, this);
}

public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
{
//new line
//	String pageInformation = SeleniumHelper.GetInstance().GetDriver().getPageSource();
	
	log.debug("Verifying item presence in the cart");
	if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
	{
		
	log.info("The item " + _itemName + " was successfully found in cart");

	if (_itemName == "Printed Summer Dress")
		{
			String innStock = SeleniumHelper.GetInstance().GetDriver().findElement(
			By.xpath("//table/tbody/tr[1]/td[3]")).getText(); 	
	     
			if (innStock =="In Stock")
			{
				log.info("The item " + _itemName + " is In Stock");
			}
			else
			{
				log.info("The item " + _itemName + " is Not In Stock");
			}
		
//			System.out.println(innStock); 
		}

	if (_itemName == "Faded Short Sleeve T-shirts")
	{
		String innStock = SeleniumHelper.GetInstance().GetDriver().findElement(
		By.xpath("//table/tbody/tr[2]/td[3]")).getText(); 	
     
		if (innStock =="In Stock")
		{
			log.info("The item " + _itemName + " is In Stock");
		}
		else
		{
			log.info("The item " + _itemName + " is Not In Stock");
		}
	
//		System.out.println(innStock); 
	}

	
	}

//new Lines
//  //table/tbody/tr[1]/td[3]
	        
/*	        
	List<WebElement> selectColor;

	By mySelector = By.xpath("/html/body/div[1]/div/section/div/div[2]/form[1]/div/ul/li");
	List<WebElement> myElements = driver.findElements(mySelector);
	for(WebElement e : myElements) 
	{
	  System.out.println(e.getText());
	}
/*
 * 
    
	if (SeleniumHelper.VerifyTextPresentOnPage("In stock"))
	{
	log.info("The item " + _itemName + " is In Stock");
    System.out.println("The item " + _itemName + " is In Stock");
	}
//new lines end
	else
	{
	log.error("The item " + _itemName + " was NOT found in cart");
	}
*/
		
	
	return MyStoreShoppingCartPage.GetInstance();
}


public MyStoreShoppingCartPage proceedToCheckOut()
{
	log.debug("Clicking the button to Check out");
	Selenium.Click(proceedToCheckoutButton);
	SeleniumHelper.Seconds(2);

	/*
 * 
	if (!SeleniumHelper.VerifyItemExists(checkOutButton))
	{
	log.info("Successfully clicked the Proceed to Check out button");
	}
else
	{
	log.error("Proceed to Check out button was not clicked properly");
	}
*/
	
	return MyStoreShoppingCartPage.GetInstance();
}

public MyStoreShoppingCartPage proceedToCheckOutadd()
{

	log.debug("Click Check out button again at address page");
	Selenium.Click(checkOutButton);
	SeleniumHelper.Seconds(2);
	
	
	return MyStoreShoppingCartPage.GetInstance();
}

public MyStoreShoppingCartPage tosCheckbox()
{
	log.debug("click Terms of Service checkbox");
	Selenium.Click(checkBox);
	SeleniumHelper.Seconds(2);
	return MyStoreShoppingCartPage.GetInstance();

}


public MyStoreShoppingCartPage shippingCheckout()
{
	log.debug("clicks Proceed to Check out button at shipping page");
	Selenium.Click(shippingCheckoutbutton);
	SeleniumHelper.Seconds(2);
	return MyStoreShoppingCartPage.GetInstance();

}


public MyStoreShoppingCartPage payByCheck()
{
	log.debug("user clicks Pay By Check");
	Selenium.Click(payByCheckoption);
	SeleniumHelper.Seconds(2);
	return MyStoreShoppingCartPage.GetInstance();

}


public MyStoreShoppingCartPage VerifyPaymentSelection(String _payOption)
{
	log.debug("verify selected Payment option is displayed at order summary page");
//	Selenium.Click(cartLink); 
	String odrsummHead = SeleniumHelper.GetInstance().GetDriver().findElement(
	By.xpath("//h3[@class='page-subheading']")).getText().toUpperCase(); 	

	
	if (odrsummHead == _payOption)
		{
		log.info( _payOption + "is selected");
		}
		else
		{
		log.error("Invalid Pay option entered");
		}
	return MyStoreShoppingCartPage.GetInstance();
}

public MyStoreShoppingCartPage ConfirmOrder()
{
	log.debug("user confirm the order");
	Selenium.Click(conirmOdrbutton);
	SeleniumHelper.Seconds(2);
	return MyStoreShoppingCartPage.GetInstance();

}

public MyStoreShoppingCartPage VerifyOrderConfirmation(String _odrMessage)
{
	log.debug("verify order conirmation message");
	
	if (SeleniumHelper.VerifyTextPresentOnPage(_odrMessage))
	{
		
	log.info("Order Confirmation message displayed successfully");

	}
	
	else
	{
		log.info("Order Confirmation message is missing");
		
	}
	
	return MyStoreShoppingCartPage.GetInstance();
}


public static MyStoreShoppingCartPage GetInstance()
{
	if (m_instance == null)
	{
	m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
	}
	return m_instance;
}

}
