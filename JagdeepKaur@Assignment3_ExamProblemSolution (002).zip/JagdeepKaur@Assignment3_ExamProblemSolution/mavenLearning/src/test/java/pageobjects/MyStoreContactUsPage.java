package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreContactUsPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreContactUsPage.class);
	private static MyStoreContactUsPage m_instance;
	@FindBy(xpath = "//*[@id=\"center_column\"]/h1")
	WebElement contactUsHeader;
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;

	private MyStoreContactUsPage(WebDriver _driver) {
		m_pageTitle = "Contact us - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreContactUsPage VerifyContactUsHeader() {
		Selenium.VerifyTextInElement(contactUsHeader, "CUSTOMER SERVICE -CONTACT US");
		return MyStoreContactUsPage.GetInstance();
	}

	public MyStoreSignInPage NavigateToSignInPage() {
		log.debug("navigating to signin page");
		Selenium.Click(signInButton);
		return MyStoreSignInPage.GetInstance();
	}

	public static MyStoreContactUsPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreContactUsPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
