package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckOutAddresses extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreCheckOutAddresses.class);
	private static MyStoreCheckOutAddresses m_instance;
	
	@FindBy(name = "processAddress")
	WebElement checkOutAddressButton;
	
	private MyStoreCheckOutAddresses(WebDriver _driver) {
		log.debug("creating check-out addresses PageObject");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public static MyStoreCheckOutAddresses GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreCheckOutAddresses(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public MyStoreCheckOutAddresses proceedToCheckOut() {
		log.debug("checking out addresses");
		Selenium.Click(checkOutAddressButton);
		return MyStoreCheckOutAddresses.GetInstance();
	}
}	