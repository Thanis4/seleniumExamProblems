package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckOutShipping extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreCheckOutShipping.class);
	private static MyStoreCheckOutShipping m_instance;

	@FindBy(name = "processCarrier")
	WebElement checkOutCarrierButton;
	
	@FindBy(id = "cgv")
	WebElement agreeCheckbox;
	
	private MyStoreCheckOutShipping(WebDriver _driver) {
		log.debug("creating check-out shipping PageObject");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public static MyStoreCheckOutShipping GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreCheckOutShipping(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public MyStoreCheckOutShipping proceedToCheckOut() {
		log.debug("checking out shipping");
		Selenium.Click(checkOutCarrierButton);
		return MyStoreCheckOutShipping.GetInstance();
	}	
	
	public MyStoreCheckOutShipping TermsOfServicesCheckbox() {
		log.debug("Agreeing to the terms of services");
		Selenium.Click(agreeCheckbox);
		return MyStoreCheckOutShipping.GetInstance();
	}	
	
}	