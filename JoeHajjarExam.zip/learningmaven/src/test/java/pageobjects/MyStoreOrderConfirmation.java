package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.support.PageFactory;

import selenium.SeleniumHelper;

public class MyStoreOrderConfirmation extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreOrderConfirmation.class);
	private static MyStoreOrderConfirmation m_instance;

	

	
	private MyStoreOrderConfirmation(WebDriver _driver) {
		log.debug("creating order confirmation PageObject");
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public static MyStoreOrderConfirmation GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreOrderConfirmation(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
	public MyStoreOrderConfirmation VerifyingSuccessmessage() {
		log.debug("Confirming your order completion");
		String expText = "Your order on My Store is complete.";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText)) {
			log.info("Order confirmed");
		} else {
			log.error("Something is wrong with the order");
		}
		return MyStoreOrderConfirmation.GetInstance();
	}
	
	
}	