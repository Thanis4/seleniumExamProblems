package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreOrderSummary extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreOrderSummary.class);
	private static MyStoreOrderSummary m_instance;

	@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button")
	WebElement confirmOrder;
	

	
	private MyStoreOrderSummary(WebDriver _driver) {
		log.debug("creating check-out shipping PageObject");
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public static MyStoreOrderSummary GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreOrderSummary(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
	public MyStoreOrderSummary VerifyingChequePayment() {
		log.debug("Confirming Cheque was used as a payment");
		String expText = "CHECK PAYMENT";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText)) {
			log.info("Payment by Cheque is confirmed");
		} else {
			log.error("This is not a payment by Cheque");
		}
		return MyStoreOrderSummary.GetInstance();
	}
	public MyStoreOrderSummary ConfirmOrder() {
		log.debug("clicking on pay by cheque method of payment");
		Selenium.Click(confirmOrder);
		return MyStoreOrderSummary.GetInstance();
	}	
	
	
	
}	