package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStorePaymentMethod extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStorePaymentMethod.class);
	private static MyStorePaymentMethod m_instance;

	@FindBy(xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[2]/div/p/a")
	WebElement payByCheque;
	

	
	private MyStorePaymentMethod(WebDriver _driver) {
		log.debug("creating check-out shipping PageObject");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}
	
	public static MyStorePaymentMethod GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStorePaymentMethod(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public MyStorePaymentMethod PayByCheque() {
		log.debug("clicking on pay by cheque method of payment");
		Selenium.Click(payByCheque);
		return MyStorePaymentMethod.GetInstance();
	}	
	
	
	
}	