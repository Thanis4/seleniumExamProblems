package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;
	@FindBy(name = "Submit")
	WebElement addToCartButton;
	
	@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")
	WebElement checkOutButton;
	
	private MyStoreShoppingCartPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public MyStoreShoppingCartPage VerifyItemsInStock(String _itemName) {
		log.debug("Verifying is in stock");
		String expText = "In stock";
		if (SeleniumHelper.VerifyTextPresentOnPage(expText)) {
			log.info("The item " + _itemName + " is in stock");
		} else {
			log.error("The item " + _itemName + " is not in stock");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}
	public static MyStoreShoppingCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public MyStoreShoppingCartPage proceedToCheckOut() {
		log.debug("Proceeding to check out");
		Selenium.Click(checkOutButton);
		return MyStoreShoppingCartPage.GetInstance();
	}

}
 
