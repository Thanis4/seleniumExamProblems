package com.seleniumttraining.day1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


public class browser_locator
{WebDriver driver;

	By loc_email = By.id("sign-into-account-email-field");
	WebElement loginEmail = driver.findElement(loc_email);

	By loc_password = By.id("sign-into-account-password-field");
	WebElement loginPassword = driver.findElement(loc_password);

	By loc_order = By.id("order-status-order-number");
	WebElement loginOrder = driver.findElement(loc_order);

	By loc_postalcode = By.id("order-status-zip-code");
	WebElement loginPostalcode = driver.findElement(loc_postalcode);
}
