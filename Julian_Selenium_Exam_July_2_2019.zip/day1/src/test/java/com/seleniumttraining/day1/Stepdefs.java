package com.seleniumttraining.day1;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreContactUsPage;
import pageobjects.MyStoreCreateAnAccountPage;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStoreMyAccountPage;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;

public class Stepdefs
{
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();
	MyStoreCreateAnAccountPage createAccountPage = MyStoreCreateAnAccountPage.GetInstance();
	MyStoreMyAccountPage myAccoutnPage = MyStoreMyAccountPage.GetInstance();
	MyStoreContactUsPage contactUsPage = MyStoreContactUsPage.GetInstance();
	MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
	MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();

	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception
	{
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage()
	{
		homePage.NavigateToSignInPage();
	}

	@When("user begins registration")
	public void user_begins_registration()
	{
		signInPage.CreateAnAccount();
	}

	@When("user enters default data")
	public void user_enters_default_data()
	{
		createAccountPage.EnterAccountDetails();
	}

	@When("user logs out")
	public void user_logs_out()
	{
		myAccoutnPage.SignOut();
	}

	@Then("verify signinpage title")
	public void verify_signinpage_title()
	{
		signInPage.VerifyTitle();
	}

	@When("user signs in")
	public void user_signs_in()
	{
		signInPage.SignIn();
	}

	@Then("verify myaccountpage title")
	public void verify_myaccountpage_title()
	{
		myAccoutnPage.VerifyTitle();
	}

	@When("user navigates to contactuspage")
	public void user_navigates_to_contactuspage()
	{
		myAccoutnPage.NavigateToContactUsPage();
	}

	@Then("verify contactuspage title")
	public void verify_contactuspage_title()
	{
		contactUsPage.VerifyTitle();
	}

	@When("user navigates to cart")
	public void user_navigates_to_cart()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@When("user clicks on cart")
	public void user_clicks_on_cart()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@Then("verify cart title")
	public void verify_cart_title()
	{
		// Write code here that turns the phrase above into concrete actions
		throw new cucumber.api.PendingException();
	}

	@When("user searches for {string}")
	public void user_searches_for(String string)
	{
		myAccoutnPage.SearchForItem(string);
		searchResultsPage.SelectItem(string);
	}

	@When("user adds item to cart")
	public void user_adds_item_to_cart()
	{
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}

	@When("user selects colour Blue")
	public void user_selects_color_blue()
	{
		itemDescriptionPage.selectcolor();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Proceed to checkout")
	public void user_clicks_proceed_to_checkout()
	{
		itemDescriptionPage.clicks_proceed_to_checkout();
		SeleniumHelper.Seconds(2);
	}

	@When("user continues shopping")
	public void user_continues_shopping()
	{
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks shopping cart")
	public void user_clicks_shopping_cart()
	{
		itemDescriptionPage.goToShoppingCart();
	}

	@Then("user verifies {string} is in cart")
	public void user_verifies_is_in_cart(String string)
	{
		shoppingCartPage.VerifyItemPresenceInCart(string);
	}

	@Then("user signs out")
	public void user_signs_out()
	{
		shoppingCartPage.SignOut();
	}

	@When("user verifies that In Stock for both items in the Avail column")
	public void user_verifies_that_for_both_items_in_the_column()
	{
		// Write code here that turns the phrase above into concrete actions
		shoppingCartPage.verify_avail_stock();
	}

	@When("user clicks Proceed to checkout in shopping cart")
	public void user_clicks_proceed_to_checkout_in_shopping_cart()
	{
		shoppingCartPage.proceed_to_check_out();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Proceed to checkout in address")
	public void user_clicks_proceed_to_checkout_in_address()
	{
		shoppingCartPage.proceed_to_check_out_address();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Terms and Conditions")
	public void user_clicks_terms_and_conditions()
	{
		shoppingCartPage.termsandcond();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Proceed to checkout in shipping")
	public void user_clicks_proceed_to_checkout_in_shipping()
	{
		shoppingCartPage.proceed_to_check_out_shipping();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Pay by cheque")
	public void user_clicks_pay_by_cheque()
	{
		shoppingCartPage.proceed_to_check_out_pay_by_cheque();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks Confirm Order")
	public void user_clicks_confirm_order()
	{
		shoppingCartPage.confirm_order();
		SeleniumHelper.Seconds(2);
	}

	@Then("user verifies confirm order")
	public void user_confirms_order()
	{
		shoppingCartPage.Verify_confirm_order();
		SeleniumHelper.Seconds(2);
	}
}
