package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject
{
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;
	@FindBy(xpath = "//a[@title='Continue shopping']/preceding::a[1]")
	static WebElement proceed_to_ARROW;

	@FindBy(xpath = "//button[@name='processAddress']")
	static WebElement proceed_to_Address;

	@FindBy(xpath = "//input[@type='checkbox']")
	static WebElement termsandc;

	@FindBy(xpath = "//button[@name='processCarrier']")
	static WebElement proceed_to_shipping;

	@FindBy(xpath = "//a[@class='cheque']")
	static WebElement pay_by_cheque;

	@FindBy(xpath = "//button[@class='button btn btn-default button-medium']")
	static WebElement confirm_my_order;

	@FindBy(xpath = "//p[@class='alert alert-success']")
	static WebElement confirm_message;

	private MyStoreShoppingCartPage(WebDriver _driver)
	{
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName)
	{
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName))
		{
			log.info("The item " + _itemName + " was successfully found in cart");
		} else
		{
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	public static MyStoreShoppingCartPage GetInstance()
	{
		if (m_instance == null)
		{
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public MyStoreShoppingCartPage verify_avail_stock()

	{

		int a = SeleniumHelper.FindElements(By.xpath("//table/tbody/tr")).size();
		int b = SeleniumHelper.FindElements(By.xpath("//span[@class='label label-success']")).size();

		// Assert.assertEquals(a, b);

		if (a == b)
		{
			log.info("The items are available");
		} else
		{
			log.error("The items are not available");
		}

		return m_instance;

	}

	public MyStoreShoppingCartPage proceed_to_check_out()

	{
		Selenium.Click(proceed_to_ARROW);

		return m_instance;

	}

	public MyStoreShoppingCartPage proceed_to_check_out_address()

	{
		Selenium.Click(proceed_to_Address);

		return m_instance;

	}

	public MyStoreShoppingCartPage termsandcond()

	{
		Selenium.Click(termsandc);

		return m_instance;

	}

	public MyStoreShoppingCartPage proceed_to_check_out_shipping()

	{
		Selenium.Click(proceed_to_shipping);

		return m_instance;

	}

	public MyStoreShoppingCartPage proceed_to_check_out_pay_by_cheque()

	{
		Selenium.Click(pay_by_cheque);

		return m_instance;

	}

	public MyStoreShoppingCartPage confirm_order()

	{
		Selenium.Click(confirm_my_order);

		return m_instance;

	}

	public MyStoreShoppingCartPage Verify_confirm_order()

	{
		if (SeleniumHelper.VerifyItemExists(confirm_message))
		{

			log.info("Success");
		} else
		{
			log.error("Failure");
		}
		return m_instance;

	}
}