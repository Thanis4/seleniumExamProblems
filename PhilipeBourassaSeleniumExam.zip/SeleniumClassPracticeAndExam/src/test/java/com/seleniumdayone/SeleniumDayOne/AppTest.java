package com.seleniumdayone.SeleniumDayOne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import selenium.SeleniumHelper;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
 
   	 	WebDriver driver = SeleniumHelper.GetInstance().GetDriver();
   	 	
   	 	SeleniumHelper.GetInstance().Get("http://beeskneesdance.com");
//   	driver.get("http://beeskneesdance.com");     
   	
   	// Site search DDL Element
//       By loc_siteSearchDDL = By.tagName("select");
//       WebElement siteSearchDDL = driver.findElement(loc_siteSearchDDL);
       
       // Site Logo Element
       By loc_logo = By.xpath("//*[@id=\"logo\"]/a/img");
       WebElement logo = driver.findElement(loc_logo);
       
       // 2nd Newsletter link Element
       By loc_newsLetterLinkB = By.className("overdefultlink");
       WebElement newsLetterLinkB = driver.findElement(loc_newsLetterLinkB);
       
       // Site search text input field element
//       By loc_searchField = By.id("keyword");
//       WebElement searchField = driver.findElement(loc_searchField);
       
       // Site search submit button element
//       By loc_searchSubmit = By.name("submit");
//       WebElement searchSubmit = driver.findElement(loc_searchSubmit);
       
       // CUSTOM XPATH
       
     
       
       // Site Logo link
//       By loc_logoLink = By.xpath("//a[@href='http://beeskneesdance.com']");
//       WebElement logoLink = driver.findElement(loc_logoLink);

       // Site search DDL Element
       By loc_siteSearchDDL = By.xpath("//select[@name='url_list']");
       WebElement siteSearchDDL = driver.findElement(loc_siteSearchDDL);
     
       // Twitter Link Footer Element
       By loc_twitterLink = By.xpath("//a[@class='twitterlink']");
       WebElement twitterLink = driver.findElement(loc_twitterLink);
       
    // Site search text input field element
       By loc_searchField = By.xpath("//input[@id='keyword']");
       WebElement searchField = driver.findElement(loc_searchField);
       
       // Site search submit button element
       By loc_searchSubmit = By.xpath("//input[@id='searchsubmit']");
       WebElement searchSubmit = driver.findElement(loc_searchSubmit);
       
//       SEARCH WEBSITE
//       searchField.sendKeys("Phil");
//       searchSubmit.click();
       
//       SeleniumHelper.GetInstance().CloseDriver();
       
//       3. Verify the title
       String currentTitle = SeleniumHelper.GetInstance().GetTitle();
       System.out.println(currentTitle);
       String expectedTitle = "Rudy's School of Bachata";
       Boolean titleVerify = SeleniumHelper.GetInstance().VerifyPageTitle(expectedTitle);
       System.out.println(titleVerify);
       
   }

    }
