package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreCheckoutPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreCheckoutPage.class);
	private static MyStoreCheckoutPage m_instance;
	@FindBy(className = "step_current")
	WebElement checkoutCurrentSection;
	@FindBy(xpath = "//button[@name='processAddress']")
	WebElement proceedToCheckoutShippingButton;
	@FindBy(id = "cgv")
	WebElement TermsOfServiceCheckbox;
	@FindBy(xpath = "//button[@name='processCarrier']")
	WebElement proceedToCheckoutPaymentButton;
	@FindBy(xpath = "//a[@title='Pay by check.']")
	WebElement payByCheckButton;
//	@FindBy(xpath = "//button[@type='submit']")
//	WebElement confirmMyOrderButton;
	@FindBy(xpath = "//button/span[text() = 'I confirm my order']")
	WebElement confirmationButtonElement;

	private MyStoreCheckoutPage(WebDriver _driver) {
		log.debug("Checkout items Added to Cart PageObject ");
		m_pageTitle = "Order - My Store";
		PageFactory.initElements(_driver, this);
	}

	// Verify the user is on the Checkout Address section

	public MyStoreCheckoutPage VerifyCheckoutAddressSection() {
		String currentStepItem = checkoutCurrentSection.getAttribute("class");
//		System.out.println(currentStepItem);
		if (currentStepItem.contains("third")) {
			log.info("The user is on the Address section of the checkout page");
		} else {
			log.error("The user is NOT on the Address section of the checkout page");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// Navigate to Checkout Page Shipping section

	public MyStoreCheckoutPage NavigateToCheckoutShipping() {
		log.debug("navigating to Checkout page Shipping section");
		Selenium.Click(proceedToCheckoutShippingButton);
		return MyStoreCheckoutPage.GetInstance();
	}

	// Verify the user is on the Checkout Page Shipping section

	public MyStoreCheckoutPage VerifyCheckoutShippingSection() {
		String currentStepItem = checkoutCurrentSection.getAttribute("class");
//			System.out.println(currentStepItem);
		if (currentStepItem.contains("four")) {
			log.info("The user is on the Shipping section of the checkout page");
		} else {
			log.error("The user is NOT on the Shipping section of the checkout page");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// Click Terms of Service Checkbox

	public MyStoreCheckoutPage ClickTermsOfServiceCheckbox() {
		log.debug("click the Terms of Service checkbox");
		Selenium.ToggleCheckBox(By.id("cgv"));
		boolean checkStatus = SeleniumHelper.VerifyCheckBoxIsChecked(By.id("cgv"));
		if (checkStatus == true) {
			log.info("The Terms of Service checkbox is selected");
		} else {
			log.error("The Terms of Service checkbox is not selected");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// Navigate to Checkout Page Payment section

	public MyStoreCheckoutPage NavigateToCheckoutPayment() {
		log.debug("navigating to Checkout page Shipping section");
		Selenium.Click(proceedToCheckoutPaymentButton);
		return MyStoreCheckoutPage.GetInstance();
	}

	// Verify the user is on the Checkout Page Payment section

	public MyStoreCheckoutPage VerifyCheckoutPaymentSection() {
		String currentStepItem = checkoutCurrentSection.getAttribute("class");
		if (currentStepItem.contains("last")) {
			log.info("The user is on the Payment section of the checkout page");
		} else {
			log.error("The user is NOT on the Payment section of the checkout page");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// Click the Pay By Check button

	public MyStoreCheckoutPage ClickPayByCheck() {
		log.debug("Click the Pay By Check button");
		Selenium.Click(payByCheckButton);
		return MyStoreCheckoutPage.GetInstance();
	}

	// verify the CHECK PAYMENT header is displayed
	
	public MyStoreCheckoutPage VerifyCheckPaymentHeader() {
		log.debug("verify the CHECK PAYMENT header is displayed");
		boolean checkPaymentHeader = SeleniumHelper.VerifyTextPresentOnPage("Check payment");
		if (checkPaymentHeader) {
			log.info("The CHECK PAYMENT header is displayed");
		} else {
			log.info("The CHECK PAYMENT header is NOT displayed");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// user clicks the I Confirm My Order button
	
	public MyStoreCheckoutPage ClickConfirmMyOrderButton() {
		log.debug("user clicks the I Confirm My Order button");
		Selenium.Click(confirmationButtonElement);
		return MyStoreCheckoutPage.GetInstance();
	}

	// verify order completion message is displayed
	
	public MyStoreCheckoutPage VerifyOrderCompletionMessage() {
		log.debug("verify the order completion message is displayed");
		boolean checkCompletionMessage = SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete.");
		if (checkCompletionMessage) {
			log.info("The order completion message is displayed");
		} else {
			log.info("The order completion message is NOT displayed");
		}
		return MyStoreCheckoutPage.GetInstance();
	}

	// verify the sign out page title
	
	public MyStoreSignInPage VerifySignOutPageTitle() {
		log.debug("verify the sign out page title");
		boolean pageTitleMatches = SeleniumHelper.VerifyPageTitle("Login - My Store");
		if (pageTitleMatches) {
			log.info("'Login - My Store' is the page title");
		} else {
			log.info("'Login - My Store' is NOT the page title");
		}
		return MyStoreSignInPage.GetInstance();
	}

	public static MyStoreCheckoutPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreCheckoutPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

}
