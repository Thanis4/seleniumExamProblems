package pageobjects;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;
	@FindBy(className = "cart_item")
	WebElement purchaseItem;
	@FindBy(xpath = "//span[@class='label']")
	WebElement stockStatusElement;
	@FindBy(linkText = "Proceed to checkout")
	WebElement proceedToCheckoutButton;

	private MyStoreShoppingCartPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	// Verify an item is present in the cart
	
	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	// Verify each item in the shopping cart is in stock
	
	public MyStoreShoppingCartPage VerifyItemsAreInStock(String _desiredStockStatus) {
		log.debug("Verifying items are in stock");
		List<WebElement> stockStatusElements = SeleniumHelper.FindElements(By.className("label"));
		for(WebElement ele : stockStatusElements){
			String itemAvailability = ele.getText();
			String backgroundColor = "rgba(85, 198, 94, 1)";
            if(itemAvailability.equals(_desiredStockStatus) && (ele.getCssValue("background-color").equals(backgroundColor))) {
            	log.info("This item is " + _desiredStockStatus);
            } else {
            	log.error("This item is not " + _desiredStockStatus);
            };
        } 
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	// Navigate to Checkout Page, Address section
	
	public MyStoreCheckoutPage NavigateToCheckoutPage() {
		log.debug("navigating to Checkout page");
		Selenium.Click(proceedToCheckoutButton);
		return MyStoreCheckoutPage.GetInstance();
	}


	public static MyStoreShoppingCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}