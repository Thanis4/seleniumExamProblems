package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreItemAddedToCartWindow extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreItemAddedToCartWindow.class);
	private static MyStoreItemAddedToCartWindow m_instance;
	@FindBy(xpath = "//span[@title = 'Continue shopping']")
	WebElement continueShoppingButton;
	@FindBy(xpath = "//a[@title = 'Proceed to checkout']")
	WebElement proceedToCheckoutButton;

	private MyStoreItemAddedToCartWindow(WebDriver _driver) {
		log.debug("creating Item Added to Cart PageObject");
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreItemDescriptionPage pressContinueShoppingButton() {
		log.debug("Clicking the button of Continue Shopping");
		Selenium.Click(continueShoppingButton);
		if (!SeleniumHelper.VerifyItemExists(continueShoppingButton)) {
			log.info("Successfully clicked the Continue Shopping button");
		} else {
			log.error("The Continue Shopping button was not clicked properly");
		}
		return MyStoreItemDescriptionPage.GetInstance();
	}

	public static MyStoreItemAddedToCartWindow GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreItemAddedToCartWindow(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}