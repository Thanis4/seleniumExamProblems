package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreMyAccountPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreMyAccountPage.class);
	private static MyStoreMyAccountPage m_instance;
	@FindBy(linkText = "Sign out")
	WebElement signOutButton;
	@FindBy(linkText = "Women")
	WebElement womenLink;
	@FindBy(linkText = "T-shirts")
	WebElement tshirt;
	@FindBy(linkText = "Blouses")
	WebElement blouse;
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;

	private MyStoreMyAccountPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreContactUsPage NavigateToContactUsPage() {
		log.debug("navigating to Contact Us page");
		Selenium.Click(contactUsButton);
		return MyStoreContactUsPage.GetInstance();
	}

	public static MyStoreMyAccountPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreMyAccountPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}
