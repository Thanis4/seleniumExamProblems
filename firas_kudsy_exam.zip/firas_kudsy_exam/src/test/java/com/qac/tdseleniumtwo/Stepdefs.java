package com.qac.tdseleniumtwo;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobjects.MyStoreHomePage;
import pageobjects.MyStoreItemAddedToCartWindow;
import pageobjects.MyStoreItemDescriptionPage;
import pageobjects.MyStorePageObject;
import pageobjects.MyStoreSearchResultsPage;
import pageobjects.MyStoreShoppingCartPage;
import pageobjects.MyStoreSignInPage;
import selenium.SeleniumHelper;

public class Stepdefs {

	MyStoreSearchResultsPage searchResultsPage = MyStoreSearchResultsPage.GetInstance();
	MyStoreItemDescriptionPage itemDescriptionPage = MyStoreItemDescriptionPage.GetInstance();
	MyStoreItemAddedToCartWindow itemAddedToCartWindow = MyStoreItemAddedToCartWindow.GetInstance();
	MyStoreShoppingCartPage shoppingCartPage = MyStoreShoppingCartPage.GetInstance();
	MyStorePageObject myAccountPage = MyStorePageObject.GetInstance();
	MyStoreHomePage homePage = MyStoreHomePage.GetInstance();
	MyStoreSignInPage signInPage = MyStoreSignInPage.GetInstance();


	@Given("^user is on homepage$")
	public void user_is_on_homepage() throws Exception {
		homePage.NavigateToThisPage();
	}

	@When("^user navigates to signinpage$")
	public void user_navigates_to_signinpage() {
		homePage.NavigateToSignInPage();
	}

	@When("user signs in")
	public void user_signs_in() {
		signInPage.SignIn();
	}

	@Then("user verifies {string} is in cart")
	public void user_verifies_is_in_cart(String string) {
	     shoppingCartPage.VerifyItemPresenceInCart(string);
	}

	@Then("user verifies items is in stock")
	public void user_verifies_items_is_in_stock() {
	     shoppingCartPage.VerifyItemPresenceInStock(2);
	}

	
	@Then("user searches for {string}")
	public void user_searches_for(String string) {
		searchResultsPage.SearchForItem(string);
		searchResultsPage.SelectItem(string);
	}

	@When("user adds item to cart")
	public void user_adds_item_to_cart() {
		itemDescriptionPage.AddItemToCart();
		SeleniumHelper.Seconds(2);
	}
	
	@When("user select {string}")
	public void user_select(String string) {
		itemDescriptionPage.UserSelect(string);
		SeleniumHelper.Seconds(2);
	}
	

	@When("user continues shopping")
	public void user_continues_shopping() {
		itemAddedToCartWindow.pressContinueShoppingButton();
		SeleniumHelper.Seconds(2);
	}

	@When("user clicks shopping cart")
	public void user_clicks_shopping_cart() {
		itemDescriptionPage.goToShoppingCart();
	}

	@When("user navigatre to proceed to checkout")
	public void user_navigatre_to_proceed_to_checkout() {
		shoppingCartPage.NavigateToProceedToCheckoutPage();
	}

	@When("user navigatre to payment")
	public void user_navigatre_to_payment() {
		shoppingCartPage.NavigateToPayment();
	}

	
	@When("user confirm address to checkout")
	public void user_confirm_address_to_checkout() {
		shoppingCartPage.NavigateConfirmAddress();
	}
	
	@When("user pay by check")
	public void user_pay_by_check() {
		shoppingCartPage.PayByCheck();
	}

	
	@When("user agree on terms of services")
	public void user_agree_on_terms_of_services() {
		shoppingCartPage.AgreeTermsServices();
	}
	
	

	
	@Then("verify order complete")
	public void verify_order_complete() {
		shoppingCartPage.VerifyOrderComplete();
	}
	
	
	@Then("verify check payment")
	public void verify_check_payment() {
		shoppingCartPage.VerifyCheckPayment();
	}

	@When("user confirm payment")
	public void user_confirm_payment() {
		shoppingCartPage.ConfirmPayment();
	}
	
	

	@Then("user signs out")
	public void user_signs_out() {
		shoppingCartPage.SignOut();
	}

}