
package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreHomePage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreHomePage.class);
	private static MyStoreHomePage m_instance;
	private String m_url;
	
	@FindBy(linkText = "Sign in")
	WebElement signInButton;
	
	@FindBy(xpath = "//*[@id=\"contact-link\"]/a")
	WebElement contactUsButton;

	@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[1]")
	WebElement firstProduct;
	
	@FindBy(xpath = "//*[@id=\"center_column\"]/ul/li[1]/div/div[2]/div[2]/a[1]")
	WebElement addToCartButton;
	
	@FindBy(xpath = "//*[@id=\"add_to_cart\"]/button")
	WebElement addMoreToCartButton;
	
	@FindBy(xpath = "//*[@id=\"color_2\"]")
	WebElement blueButton;
	
	
	
	@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[1]/h2/text()")
	WebElement productAdded;
	
	@FindBy(xpath = "//*[@id=\"layer_cart\"]/div[1]/div[2]/div[4]/span")
	WebElement continueShopping;
	
	@FindBy(xpath = "//*[@id=\"header\"]/div[3]/div/div/div[3]/div/a")
	WebElement cartButton;
	
	
	
	@FindBy(xpath = "//*[@id=\"product_1_2_0_120258\"]/td[3]/span")
	WebElement inStock;
	
	
	@FindBy(id = "search_query_top")
	WebElement searchInput;
	
	@FindBy(name = "submit_search")
	WebElement searchButton;
	
	@FindBy(className = "heading-counter")
	WebElement searchCounter;
	
	
	private MyStoreHomePage(WebDriver _driver) {
		log.debug("creating Home Page PageObject");
		m_url = "http://automationpractice.com/index.php";
		m_pageTitle = "My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreHomePage NavigateToThisPage() {
		SeleniumHelper.Get(m_url);
		return GetInstance();
	}

	public MyStoreSignInPage NavigateToSignInPage() {
		log.debug("navigating to signin page");
		Selenium.Click(signInButton);
		return MyStoreSignInPage.GetInstance();
	}

	public MyStoreHomePage NavigateToMyAccountPage() {
		log.debug("navigating to my account page");
		SeleniumHelper.Get(m_url+"?controller=my-account");
		return MyStoreHomePage.GetInstance();
	}

	
	public MyStoreHomePage NavigateToCartPage() {
		log.debug("navigating to cart page");
		SeleniumHelper.Get(m_url+"?controller=order");
		return MyStoreHomePage.GetInstance();
	}


	
	
	public MyStoreHomePage SearchForMoreProducts() {
		String product = "Faded Short Sleeve T-shirts";
		log.debug("SEARCHING .... ");
		Selenium.Input(searchInput, product);
		Selenium.Click(searchButton);
		log.info("search for product : " + product );
		
		Actions action = new Actions(SeleniumHelper.GetInstance().GetDriver());
		action.moveToElement(firstProduct).click(blueButton).build().perform();

		Selenium.Click(addMoreToCartButton);
		Selenium.Click(continueShopping);

		Selenium.Click(cartButton);
//		log.debug("go to item detail " );
//		Selenium.Click(firstProduct);
		return MyStoreHomePage.GetInstance();
	}
	

	
	public MyStoreHomePage SearchForProduct() {
		String product = "Printed Summer Dress";
		log.debug("SEARCHING .... ");
		Selenium.Input(searchInput, product);
		Selenium.Click(searchButton);
		log.info("search for product : " + product );
		
		Actions action = new Actions(SeleniumHelper.GetInstance().GetDriver());
		action.moveToElement(firstProduct).click(addToCartButton).build().perform();
		

		
//		log.debug("go to item detail " );
//		Selenium.Click(firstProduct);
		return MyStoreHomePage.GetInstance();
	}
	
	
	public MyStoreHomePage VerifyCartPage() {
		
		log.debug("virefiy  cart ");
		
		if (SeleniumHelper.VerifyPageTitle("Order - My Store")) {
		    WebDriverWait wait5 = new WebDriverWait(SeleniumHelper.GetInstance().GetDriver(), 100);
		    
			

		    wait5.until(ExpectedConditions.visibilityOf(inStock));
			
					
		} else {
			log.info("Verify Cart page Error");
			throw new AssertionError("Verify Cart Page 2");
		}
	
		Selenium.Click(continueShopping);

		return MyStoreHomePage.GetInstance();
	}
	
	

	public MyStoreHomePage VerifyCart() {
		
		log.debug("virefiy  cart ");
		

		if (SeleniumHelper.VerifyTextPresentOnPage("Product successfully added to your shopping cart")) {
			log.info("Verify Cart Done");
		} else {
			log.info("Verify Cart Error");
			throw new AssertionError("Verify");
		}
	
		Selenium.Click(continueShopping);

//		Selenium.VerifyTextInElement(productAdded, "Product successfully added to your shopping cart");
		return MyStoreHomePage.GetInstance();
	}
	
	
	
	public static MyStoreHomePage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreHomePage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}

	public void TriggerAssert() throws AssertionError {
		throw new AssertionError("This should FAIL");
	}


}