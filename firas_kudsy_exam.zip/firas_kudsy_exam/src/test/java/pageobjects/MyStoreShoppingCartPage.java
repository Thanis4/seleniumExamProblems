package pageobjects;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import selenium.Selenium;
import selenium.SeleniumHelper;

public class MyStoreShoppingCartPage extends MyStorePageObject {
	private static final Logger log = LogManager.getLogger(MyStoreShoppingCartPage.class);
	private static MyStoreShoppingCartPage m_instance;
private String inStock = "//*[@id=\"product_1_2_0_120258\"]/td[3]/span";



@FindBy(xpath = "//*[@id=\"center_column\"]/p[2]/a[1]")
WebElement checkoutButton;

@FindBy(xpath = "//*[@id=\"cart_navigation\"]/button")
WebElement confirmButton;


@FindBy(xpath = "//*[@id=\"center_column\"]/form/p/button")
WebElement confirmAddressButton;

@FindBy(xpath = "//*[@id=\"form\"]/p/button")
WebElement confirmShippingButton;



@FindBy(xpath = "//*[@id=\"HOOK_PAYMENT\"]/div[2]/div/p/a")
WebElement payByCheckButton;


	private MyStoreShoppingCartPage(WebDriver _driver) {
		m_pageTitle = "My account - My Store";
		PageFactory.initElements(_driver, this);
	}

	public MyStoreShoppingCartPage VerifyItemPresenceInCart(String _itemName) {
		log.debug("Verifying item presence in the cart");
		if (SeleniumHelper.VerifyTextPresentOnPage(_itemName)) {
			log.info("The item " + _itemName + " was successfully found in cart");
		} else {
			log.error("The item " + _itemName + " was NOT found in cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	
	public MyStoreShoppingCartPage VerifyItemPresenceInStock(Integer length) {
		log.debug("Verifying item presence in the cart");
		
		if (SeleniumHelper.CountTextPresentOnPage(inStock, length)) {
			log.info("The item count was successfully found in cart");
		} else {
			log.error("The item count was NOT found in cart");
			// throw new AssertionError("Verify item presence in the cart");
		}
		return MyStoreShoppingCartPage.GetInstance();
	}

	
	public MyStoreShoppingCartPage NavigateConfirmAddress() {
		Selenium.Click(confirmAddressButton);		
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	public MyStoreShoppingCartPage NavigateToProceedToCheckoutPage() {
		Selenium.Click(checkoutButton);		
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	public MyStoreShoppingCartPage NavigateToPayment() {
		Selenium.Click(confirmShippingButton);		
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	
	
	public MyStoreShoppingCartPage PayByCheck() {
		Selenium.Click(payByCheckButton);		
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	
	public MyStoreShoppingCartPage AgreeTermsServices() {
		
		Selenium.CheckBox(By.id("cgv"), true);
		return MyStoreShoppingCartPage.GetInstance();
	}
	
	public MyStoreShoppingCartPage ConfirmPayment() {
		
		Selenium.Click(confirmButton);

		return MyStoreShoppingCartPage.GetInstance();
	}
	
	
	
public MyStoreShoppingCartPage VerifyOrderComplete() {
		
		log.debug("virefiy  order complete ");
		if (SeleniumHelper.VerifyTextPresentOnPage("Your order on My Store is complete.")) {
			log.info("Verify order complete Done");

		} else {
			log.error("Verify order complete Error");
			// throw new AssertionError("Verify order conplete");
		}
	

		return MyStoreShoppingCartPage.GetInstance();
	}

	
	public MyStoreShoppingCartPage VerifyCheckPayment() {
		
		log.debug("virefiy  check paymnet ");
		if (SeleniumHelper.VerifyTextPresentOnPage("CHECK PAYMENT")) {
			log.info("Verify check paymnet Done");

		} else {
			log.error("Verify check paymnet Error");
			// throw new AssertionError("Verify check paymnet");
		}
	

		return MyStoreShoppingCartPage.GetInstance();
	}

	
	
	
	public static MyStoreShoppingCartPage GetInstance() {
		if (m_instance == null) {
			m_instance = new MyStoreShoppingCartPage(SeleniumHelper.GetInstance().GetDriver());
		}
		return m_instance;
	}
}